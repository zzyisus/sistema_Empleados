package view;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {

        // Ejecución recomendada de interfaces gráficas en Swing
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                // Crear ventana principal
                VentanaEmpleado ventana = new VentanaEmpleado();
                ventana.setTitle("Sistema de Pago de Empleados");
                ventana.setLocationRelativeTo(null); // Centrar en pantalla
                ventana.setVisible(true);
            }
        });
    }
}
