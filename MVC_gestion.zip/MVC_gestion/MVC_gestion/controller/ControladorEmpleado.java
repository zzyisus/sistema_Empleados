package controller;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.Empleado;

public class ControladorEmpleado {

    private Conexion conexion = new Conexion();

    // ---------------------- VALIDACIÓN ----------------------
    private boolean validar(String nombre, String fechaInicio, String fechaTermino) {

        if (nombre.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Nombre es obligatorio.");
            return false;
        }
        if (fechaInicio.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Fecha Inicio es obligatoria.");
            return false;
        }
        if (fechaTermino.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Fecha Término es obligatoria.");
            return false;
        }
        return true;
    }

    // ---------------------- AGREGAR ----------------------
    public void agregarRegistro(String nombre, String fechaInicio, String fechaTermino,
                                String contrato, boolean salud, boolean afp) {

        if (!validar(nombre, fechaInicio, fechaTermino)) return;

        String sql = "INSERT INTO empleado (nombreEmpleado, fechaInicio, fechaTermino, tipoContrato, planSalud, afp) "
                   + "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection con = conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, nombre);
            ps.setString(2, fechaInicio);
            ps.setString(3, fechaTermino);
            ps.setString(4, contrato);
            ps.setBoolean(5, salud);
            ps.setBoolean(6, afp);

            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Empleado agregado correctamente.");

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al agregar: " + e.getMessage());
        }
    }

    // ---------------------- LISTAR ----------------------
    public List<Empleado> cargarRegistros() {

        List<Empleado> lista = new ArrayList<>();
        String sql = "SELECT * FROM empleado";

        try (Connection con = conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(new Empleado(
                        rs.getInt("IdEmpleado"),
                        rs.getString("nombreEmpleado"),
                        rs.getString("fechaInicio"),
                        rs.getString("fechaTermino"),
                        rs.getString("tipoContrato"),
                        rs.getBoolean("planSalud"),
                        rs.getBoolean("afp")
                ));
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar: " + e.getMessage());
        }

        return lista;
    }

    // ---------------------- MODIFICAR ----------------------
    public void modificarRegistro(int id, String nombre, String fechaInicio, String fechaTermino,
                                  String contrato, boolean salud, boolean afp) {

        if (!validar(nombre, fechaInicio, fechaTermino)) return;

        String sql = "UPDATE empleado SET nombreEmpleado=?, fechaInicio=?, fechaTermino=?, "
                   + "tipoContrato=?, planSalud=?, afp=? WHERE IdEmpleado=?";

        try (Connection con = conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, nombre);
            ps.setString(2, fechaInicio);
            ps.setString(3, fechaTermino);
            ps.setString(4, contrato);
            ps.setBoolean(5, salud);
            ps.setBoolean(6, afp);
            ps.setInt(7, id);

            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Empleado modificado correctamente.");

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar: " + e.getMessage());
        }
    }

    // ---------------------- ELIMINAR ----------------------
    public void eliminarRegistro(int id) {

        String sql = "DELETE FROM empleado WHERE IdEmpleado=?";

        try (Connection con = conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Empleado eliminado correctamente.");

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar: " + e.getMessage());
        }
    }

    // ---------------------- CONSULTAR ----------------------
    public Empleado consultarRegistro(int id) {

        String sql = "SELECT * FROM empleado WHERE IdEmpleado=?";

        try (Connection con = conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new Empleado(
                        rs.getInt("IdEmpleado"),
                        rs.getString("nombreEmpleado"),
                        rs.getString("fechaInicio"),
                        rs.getString("fechaTermino"),
                        rs.getString("tipoContrato"),
                        rs.getBoolean("planSalud"),
                        rs.getBoolean("afp")
                );
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al consultar: " + e.getMessage());
        }

        return null;
    }

}
