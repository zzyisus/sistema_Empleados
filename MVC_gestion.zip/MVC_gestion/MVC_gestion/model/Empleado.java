package model;

public class Empleado {

    private int id;
    private String nombre;
    private String fechaInicio;
    private String fechaTermino;
    private String tipoContrato;
    private boolean planSalud;
    private boolean afp;

    public Empleado() {}

    public Empleado(String nombre, String fechaInicio, String fechaTermino, String tipoContrato,
                    boolean planSalud, boolean afp) {
        this.nombre = nombre;
        this.fechaInicio = fechaInicio;
        this.fechaTermino = fechaTermino;
        this.tipoContrato = tipoContrato;
        this.planSalud = planSalud;
        this.afp = afp;
    }

    public Empleado(int id, String nombre, String fechaInicio, String fechaTermimo,
                    String tipoContrato, boolean planSalud, boolean afp) {
        this.id = id;
        this.nombre = nombre;
        this.fechaInicio = fechaInicio;
        this.fechaTermino = fechaTermimo;
        this.tipoContrato = tipoContrato;
        this.planSalud = planSalud;
        this.afp = afp;
    }

    // ================= GETTERS =================

    public int getId() { return id; }

    public String getNombre() { return nombre; }

    public String getFechaInicio() { return fechaInicio; }

    public String getFechaTermino() { return fechaTermino; }

    public String getTipoContrato() { return tipoContrato; }

    public boolean getPlanSalud() { return planSalud; }

    public boolean getAfp() { return afp; }

    // ===== LOS MÉTODOS QUE NECESITA TU VENTANA =====

    public boolean isSalud() { return planSalud; } 

    public boolean isAfp() { return afp; } 

    // ================= SETTERS =================

    public void setId(int id) { this.id = id; }

    public void setNombre(String nombre) { this.nombre = nombre; }

    public void setFechaInicio(String fechaInicio) { this.fechaInicio = fechaInicio; }

    public void setFechaTermino(String fechaTermino) { this.fechaTermino = fechaTermino; }

    public void setTipoContrato(String tipoContrato) { this.tipoContrato = tipoContrato; }

    public void setPlanSalud(boolean planSalud) { this.planSalud = planSalud; }

    
