package view;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import controller.ControladorEmpleado;
import model.Empleado;

import java.util.List;

public class VentanaEmpleado extends Frame {

    // Componentes de la interfaz
    private Label lblId, lblNombre, lblFechaInicio, lblFechaTermino, lblContrato;
    private TextField txtId, txtNombre, txtFechaInicio, txtFechaTermino;
    private Choice cbContrato;
    private Checkbox chkSalud, chkAfp;

    private Button btnAgregar, btnConsultar, btnModificar, btnEliminar;

    private JTable tabla;
    private DefaultTableModel modeloTabla;
    private JScrollPane scroll;

    private ControladorEmpleado controlador = new ControladorEmpleado();

    public VentanaEmpleado() {
        setLayout(null);
        setSize(1100, 500);
        setTitle("Sistema de Gestión de Pagos");
        setBackground(new Color(255, 182, 193));
        setLocationRelativeTo(null);

        configurarCamposDeEntrada();
        configurarBotones();
        configurarTablaDeDatos();
        configurarEventos();
        cargarTabla();
    }

    // =========================================================
    // CAMPOS
    // =========================================================
    private void configurarCamposDeEntrada() {

        lblId = new Label("ID Empleado:");
        lblId.setBounds(50, 80, 120, 25);
        add(lblId);

        txtId = new TextField();
        txtId.setBounds(180, 80, 200, 25);
        add(txtId);

        lblNombre = new Label("Nombre:");
        lblNombre.setBounds(50, 120, 120, 25);
        add(lblNombre);

        txtNombre = new TextField();
        txtNombre.setBounds(180, 120, 200, 25);
        add(txtNombre);

        lblFechaInicio = new Label("Fecha Inicio:");
        lblFechaInicio.setBounds(50, 160, 120, 25);
        add(lblFechaInicio);

        txtFechaInicio = new TextField("YYYY-MM-DD");
        txtFechaInicio.setBounds(180, 160, 200, 25);
        add(txtFechaInicio);

        lblFechaTermino = new Label("Fecha Término:");
        lblFechaTermino.setBounds(50, 200, 120, 25);
        add(lblFechaTermino);

        txtFechaTermino = new TextField("YYYY-MM-DD");
        txtFechaTermino.setBounds(180, 200, 200, 25);
        add(txtFechaTermino);

        lblContrato = new Label("Tipo de Contrato:");
        lblContrato.setBounds(50, 240, 120, 25);
        add(lblContrato);

        cbContrato = new Choice();
        cbContrato.add("Indefinido");
        cbContrato.add("Plazo Fijo");
        cbContrato.add("Honorario");
        cbContrato.setBounds(180, 240, 200, 25);
        add(cbContrato);

        chkSalud = new Checkbox("Plan de Salud");
        chkSalud.setBounds(50, 280, 150, 25);
        add(chkSalud);

        chkAfp = new Checkbox("AFP");
        chkAfp.setBounds(200, 280, 150, 25);
        add(chkAfp);
    }

    // =========================================================
    // BOTONES
    // =========================================================
    private void configurarBotones() {

        btnAgregar = new Button("Agregar");
        btnAgregar.setBounds(50, 330, 120, 40);
        add(btnAgregar);

        btnConsultar = new Button("Consultar");
        btnConsultar.setBounds(180, 330, 120, 40);
        add(btnConsultar);

        btnModificar = new Button("Modificar");
        btnModificar.setBounds(50, 380, 120, 40);
        add(btnModificar);

        btnEliminar = new Button("Eliminar");
        btnEliminar.setBounds(180, 380, 120, 40);
        add(btnEliminar);
    }

    // =========================================================
    // TABLA
    // =========================================================
    private void configurarTablaDeDatos() {

        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("ID");
        modeloTabla.addColumn("Nombre");
        modeloTabla.addColumn("Fecha Inicio");
        modeloTabla.addColumn("Fecha Término");
        modeloTabla.addColumn("Tipo Contrato");
        modeloTabla.addColumn("Plan Salud");
        modeloTabla.addColumn("AFP");

        tabla = new JTable(modeloTabla);
        scroll = new JScrollPane(tabla);
        scroll.setBounds(420, 60, 650, 370);
        add(scroll);
    }

    // =========================================================
    // EVENTOS
    // =========================================================
    private void configurarEventos() {

        // ---------- AGREGAR ----------
        btnAgregar.addActionListener(e -> {
            controlador.agregarRegistro(
                txtNombre.getText(),
                txtFechaInicio.getText(),
                txtFechaTermino.getText(),
                cbContrato.getSelectedItem(),
                chkSalud.getState(),
                chkAfp.getState()
            );
            limpiar();
            cargarTabla();
        });

        // ---------- CONSULTAR ----------
        btnConsultar.addActionListener(e -> {
            if (txtId.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Ingrese un ID.");
                return;
            }

            int id = Integer.parseInt(txtId.getText());
            Empleado emp = controlador.consultarRegistro(id);

            if (emp != null) {
                txtNombre.setText(emp.getNombre());
                txtFechaInicio.setText(emp.getFechaInicio());
                txtFechaTermino.setText(emp.getFechaTermino());
                cbContrato.select(emp.getTipoContrato());
                chkSalud.setState(emp.isSalud());
                chkAfp.setState(emp.isAfp());
            }
        });

        // ---------- MODIFICAR ----------
        btnModificar.addActionListener(e -> {

            if (txtId.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Ingrese un ID para modificar.");
                return;
            }

            controlador.modificarRegistro(
                Integer.parseInt(txtId.getText()),
                txtNombre.getText(),
                txtFechaInicio.getText(),
                txtFechaTermino.getText(),
                cbContrato.getSelectedItem(),
                chkSalud.getState(),
                chkAfp.getState()
            );
            limpiar();
            cargarTabla();
        });

        // ---------- ELIMINAR ----------
        btnEliminar.addActionListener(e -> {
            if (txtId.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Ingrese un ID para eliminar.");
                return;
            }

            controlador.eliminarRegistro(Integer.parseInt(txtId.getText()));
            limpiar();
            cargarTabla();
        });

        // ---------- CERRAR VENTANA ----------
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }

    // =========================================================
    // LLENAR LA TABLA
    // =========================================================
    private void cargarTabla() {
        modeloTabla.setRowCount(0);

        List<Empleado> lista = controlador.cargarRegistros();

        for (Empleado emp : lista) {
            modeloTabla.addRow(new Object[]{
                emp.getId(),
                emp.getNombre(),
                emp.getFechaInicio(),
                emp.getFechaTermino(),
                emp.getTipoContrato(),
                emp.isSalud(),
                emp.isAfp()
            });
        }
    }

    // Limpiar campos
    private void limpiar() {
        txtId.setText("");
        txtNombre.setText("");
        txtFechaInicio.setText("");
        txtFechaTermino.setText("");
        chkSalud.setState(false);
        chkAfp.setState(false);
    }
}
